"use client";

import { useState } from "react";
import Reveal from "./Reveal";
import { PrismMark } from "./Logo";

type PillarId = "marketplace" | "saas" | "ia";

const PILLARS: {
  id: PillarId;
  n: string;
  title: string;
  tag: string;
  body: string;
  points: string[];
}[] = [
  {
    id: "marketplace",
    n: "01",
    title: "Marketplace Público",
    tag: "O palco das marcas",
    body: "Consumidores descobrem produtos físicos e digitais em uma vitrine curada. Compram diretamente ou são direcionados às plataformas parceiras — com rastreio de ponta a ponta.",
    points: ["Vitrine curada", "Compra direta ou redirecionamento", "Rastreio de conversão"],
  },
  {
    id: "saas",
    n: "02",
    title: "SaaS Comercial",
    tag: "O centro de comando",
    body: "Vendedores e afiliados administram produtos, campanhas, links, pedidos, comissões e resultados em um painel único — com automações que eliminam o trabalho manual.",
    points: ["Produtos & campanhas", "Links e comissões", "Pedidos e resultados"],
  },
  {
    id: "ia",
    n: "03",
    title: "Inteligência Comercial",
    tag: "O Radar",
    body: "Radar de Produtos, análises, automações e agentes de IA conectados aos seus dados autorizados. Decisões em tempo real, sem planilhas e sem achismo.",
    points: ["Radar de Produtos", "Agentes de IA", "Análises em tempo real"],
  },
];

const PRODUCTS = [
  { name: "Sérum Vitamina C 30ml", type: "Físico", price: "R$ 149,90", sales: 312, bar: 62 },
  { name: "Curso: Tráfego Pago", type: "Digital", price: "R$ 497,00", sales: 1204, bar: 94 },
  { name: "Kit Skincare Premium", type: "Físico", price: "R$ 289,90", sales: 486, bar: 71 },
  { name: "Template Notion Pro", type: "Digital", price: "R$ 89,00", sales: 2310, bar: 88 },
];

const ORDERS = [
  { id: "#48213", product: "Curso: Tráfego Pago", value: "R$ 497,00", status: "Pago", tone: "text-[#22d3ee] bg-[rgba(34,211,238,0.12)]" },
  { id: "#48212", product: "Kit Skincare Premium", value: "R$ 289,90", status: "Aprovado", tone: "text-[#a855f7] bg-[rgba(168,85,247,0.14)]" },
  { id: "#48211", product: "Sérum Vitamina C 30ml", value: "R$ 149,90", status: "Em análise", tone: "text-[#fb923c] bg-[rgba(251,146,60,0.14)]" },
  { id: "#48210", product: "Template Notion Pro", value: "R$ 89,00", status: "Pago", tone: "text-[#22d3ee] bg-[rgba(34,211,238,0.12)]" },
];

const AGENTS = [
  { name: "Agente de Precificação", metric: "3 SKUs ajustados", state: "Ativo" },
  { name: "Agente de Campanhas", metric: "CPC −12% hoje", state: "Ativo" },
  { name: "Agente de Afiliados", metric: "2 aprovações", state: "Ativo" },
  { name: "Agente de Insights", metric: "Relatório 09h", state: "Concluído" },
];

const anim = { animation: "feed-in 0.55s cubic-bezier(0.16,1,0.3,1)" } as const;

function Panel({ id }: { id: PillarId }) {
  if (id === "marketplace") {
    return (
      <div style={anim} className="space-y-3">
        <div className="grid gap-3 sm:grid-cols-2">
          {PRODUCTS.map((p) => (
            <div
              key={p.name}
              className="rounded-xl border border-[var(--color-line)] bg-white/[0.02] p-3.5 transition-colors hover:border-[rgba(125,211,252,0.35)]"
            >
              <div className="flex items-start justify-between gap-2">
                <p className="text-sm font-medium text-[var(--color-cream)]">{p.name}</p>
                <span className="chip shrink-0 !px-2 !py-0.5 !text-[0.62rem]">{p.type}</span>
              </div>
              <div className="mt-2.5 flex items-center justify-between text-xs text-[var(--color-mist-soft)]">
                <span className="font-display text-base text-[var(--color-cream)]">{p.price}</span>
                <span>{p.sales.toLocaleString("pt-BR")} vendas</span>
              </div>
              <div className="mt-2.5 h-1 overflow-hidden rounded-full bg-white/[0.06]">
                <div
                  className="h-full rounded-full bg-[linear-gradient(90deg,#22d3ee,#a855f7)]"
                  style={{ width: `${p.bar}%` }}
                />
              </div>
            </div>
          ))}
        </div>
        <div className="flex flex-wrap items-center justify-center gap-2 rounded-xl border border-dashed border-[var(--color-line)] bg-white/[0.015] px-3 py-3 text-[0.72rem] text-[var(--color-mist)]">
          <span className="rounded-full bg-[rgba(34,211,238,0.12)] px-2.5 py-1 text-[var(--color-cyan)]">Consumidor</span>
          <span aria-hidden="true">→</span>
          <span className="rounded-full bg-[rgba(168,85,247,0.14)] px-2.5 py-1 text-[#c084fc]">Compra direta</span>
          <span className="text-[var(--color-mist-soft)]">ou</span>
          <span className="rounded-full bg-[rgba(251,146,60,0.14)] px-2.5 py-1 text-[#fb923c]">Parceiro · 6,4% conv.</span>
        </div>
      </div>
    );
  }

  if (id === "saas") {
    return (
      <div style={anim} className="space-y-3">
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          {[
            { l: "Pedidos", v: "1.284" },
            { l: "Comissões", v: "R$ 84,2k" },
            { l: "Campanhas", v: "12" },
            { l: "Afiliados", v: "348" },
          ].map((k) => (
            <div key={k.l} className="rounded-xl border border-[var(--color-line)] bg-white/[0.02] p-3">
              <p className="text-[0.66rem] uppercase tracking-wider text-[var(--color-mist-soft)]">{k.l}</p>
              <p className="mt-1 font-display text-xl font-medium text-[var(--color-cream)]">{k.v}</p>
            </div>
          ))}
        </div>
        <div className="overflow-hidden rounded-xl border border-[var(--color-line)]">
          <div className="flex items-center gap-3 border-b border-[var(--color-line)] bg-white/[0.03] px-3.5 py-2 text-[0.66rem] uppercase tracking-wider text-[var(--color-mist-soft)]">
            <span className="flex-1">Pedido</span>
            <span className="hidden flex-1 sm:block">Produto</span>
            <span className="w-16 text-right">Valor</span>
            <span className="w-20 text-right">Status</span>
          </div>
          {ORDERS.map((o) => (
            <div
              key={o.id}
              className="flex items-center gap-3 border-b border-[var(--color-line-soft)] px-3.5 py-2.5 text-sm last:border-0 hover:bg-white/[0.02]"
            >
              <span className="flex-1 text-[var(--color-mist)]">{o.id}</span>
              <span className="hidden flex-1 truncate text-[var(--color-cream)] sm:block">{o.product}</span>
              <span className="w-16 text-right text-[var(--color-cream)]">{o.value}</span>
              <span className={`w-20 text-right text-[0.66rem] ${o.tone}`}>
                <span className="rounded-full px-2 py-0.5">{o.status}</span>
              </span>
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div style={anim} className="space-y-3">
      <div className="rounded-xl border border-[rgba(168,85,247,0.3)] bg-[linear-gradient(140deg,rgba(34,211,238,0.10),rgba(168,85,247,0.12))] p-4">
        <div className="flex items-center gap-2 text-[0.7rem] font-semibold uppercase tracking-widest text-[#c084fc]">
          <span className="h-1.5 w-1.5 animate-ping rounded-full bg-[#a855f7]" />
          Alerta do Radar
        </div>
        <p className="mt-2 text-sm text-[var(--color-cream)]">
          Oportunidade detectada: <strong className="font-semibold">“home office”</strong> subiu
          <span className="text-[var(--color-cyan)]"> +27% </span>
          em demanda na sua região nos últimos 7 dias.
        </p>
      </div>
      <div className="grid gap-2.5 sm:grid-cols-2">
        {AGENTS.map((a) => (
          <div
            key={a.name}
            className="flex items-center justify-between gap-3 rounded-xl border border-[var(--color-line)] bg-white/[0.02] px-3.5 py-3"
          >
            <div className="min-w-0">
              <p className="truncate text-sm text-[var(--color-cream)]">{a.name}</p>
              <p className="text-[0.7rem] text-[var(--color-mist-soft)]">{a.metric}</p>
            </div>
            <span
              className={`chip shrink-0 !text-[0.62rem] ${
                a.state === "Ativo"
                  ? "!border-[rgba(34,211,238,0.4)] !text-[var(--color-cyan)]"
                  : "!text-[var(--color-mist-soft)]"
              }`}
            >
              {a.state}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}

export default function Ecosystem() {
  const [active, setActive] = useState<PillarId>("marketplace");
  const current = PILLARS.find((p) => p.id === active)!;

  return (
    <section id="ecossistema" className="relative py-24 sm:py-32">
      <div className="container-lux">
        <Reveal className="mx-auto max-w-3xl text-center">
          <span className="eyebrow">O Ecossistema</span>
          <h2 className="mt-6 text-[clamp(2rem,4.5vw,3.4rem)] font-light">
            Um ecossistema. <span className="text-spectrum">Três forças.</span>
          </h2>
          <p className="mt-5 text-[var(--color-mist)]">
            Três negócios distintos operando em sintonia sob a mesma inteligência.
            Clique para entrar em cada camada.
          </p>
        </Reveal>

        <Reveal delay={100}>
          {/* tab pills */}
          <div
            role="tablist"
            aria-label="Camadas do ecossistema"
            className="mt-12 flex flex-col gap-2.5 sm:flex-row sm:justify-center"
          >
            {PILLARS.map((p) => {
              const on = active === p.id;
              return (
                <button
                  key={p.id}
                  role="tab"
                  aria-selected={on}
                  onClick={() => setActive(p.id)}
                  data-cursor
                  className={`group relative flex flex-1 flex-col items-start gap-0.5 overflow-hidden rounded-2xl border px-5 py-4 text-left transition-all duration-500 sm:max-w-[240px] ${
                    on
                      ? "border-[rgba(125,211,252,0.5)] bg-[linear-gradient(140deg,rgba(34,211,238,0.10),rgba(168,85,247,0.10))]"
                      : "border-[var(--color-line)] bg-white/[0.02] hover:border-[rgba(125,211,252,0.3)]"
                  }`}
                >
                  <span className="flex items-center gap-2">
                    <span
                      className={`font-display text-lg ${on ? "text-spectrum" : "text-[var(--color-mist-soft)]"}`}
                    >
                      {p.n}
                    </span>
                    <span
                      className={`text-sm font-medium ${on ? "text-[var(--color-cream)]" : "text-[var(--color-mist)]"}`}
                    >
                      {p.title}
                    </span>
                  </span>
                  <span className="text-[0.7rem] text-[var(--color-mist-soft)]">{p.tag}</span>
                  <span
                    className={`absolute inset-x-0 bottom-0 h-[2px] origin-left bg-[linear-gradient(90deg,#22d3ee,#a855f7,#fb923c)] transition-transform duration-500 ${
                      on ? "scale-x-100" : "scale-x-0"
                    }`}
                  />
                </button>
              );
            })}
          </div>

          {/* console window */}
          <div className="glass-strong mt-6 overflow-hidden rounded-3xl shadow-[0_50px_130px_-50px_rgba(0,0,0,0.95)]">
            <div className="flex items-center justify-between gap-3 border-b border-[var(--color-line)] px-5 py-3.5">
              <span className="flex min-w-0 items-center gap-2.5">
                <PrismMark size={22} />
                <span className="truncate text-sm font-medium text-[var(--color-cream)]">
                  GestãoFácil <span className="text-[var(--color-mist-soft)]">/</span>{" "}
                  <span className="text-spectrum">{current.title}</span>
                </span>
              </span>
              <span className="chip shrink-0">
                <span className="h-1.5 w-1.5 rounded-full bg-[var(--color-cyan)] shadow-[0_0_8px_2px_rgba(34,211,238,0.6)]" />
                ao vivo
              </span>
            </div>

            <div className="p-5">
              <div key={active}>
                <Panel id={active} />
              </div>

              <div className="mt-5 border-t border-[var(--color-line)] pt-4">
                <p className="max-w-3xl text-sm leading-relaxed text-[var(--color-mist)]">
                  {current.body}
                </p>
                <ul className="mt-4 flex flex-wrap gap-2.5">
                  {current.points.map((pt) => (
                    <li key={pt} className="chip">
                      <svg width="13" height="13" viewBox="0 0 24 24" fill="none" aria-hidden="true" className="text-[var(--color-cyan)]">
                        <path d="M20 6L9 17l-5-5" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" />
                      </svg>
                      {pt}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
