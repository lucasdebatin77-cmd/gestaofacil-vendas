"use client";

import { useEffect, useState } from "react";
import { PrismMark } from "./Logo";

const WORD = "GestãoFácil".split("");

export default function Preloader() {
  const [done, setDone] = useState(false);
  const [hidden, setHidden] = useState(false);

  useEffect(() => {
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduce) {
      setDone(true);
      setHidden(true);
      window.dispatchEvent(new Event("gf:ready"));
      return;
    }
    const t1 = setTimeout(() => setDone(true), 1900);
    const t2 = setTimeout(() => {
      setHidden(true);
      window.dispatchEvent(new Event("gf:ready"));
    }, 2600);
    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
    };
  }, []);

  if (hidden) return null;

  return (
    <div className={`preloader ${done ? "is-done" : ""}`} aria-hidden="true">
      <div className="flex flex-col items-center px-6 text-center">
        <span className="animate-float">
          <PrismMark size={68} />
        </span>
        <div className="preloader-word" aria-label="GestãoFácil">
          {WORD.map((c, i) => (
            <span
              key={i}
              className={i >= 6 ? "text-spectrum" : "text-chrome"}
              style={{ animationDelay: `${0.25 + i * 0.05}s` }}
            >
              {c}
            </span>
          ))}
        </div>
        <div className="mt-2 flex items-center gap-2.5">
          <span className="spectrum-rule w-7" />
          <span className="font-mark text-[0.6rem] font-semibold tracking-[0.45em] text-[var(--color-mist)]">
            VENDAS
          </span>
          <span className="spectrum-rule w-7" />
        </div>
        <div className="preloader-bar">
          <span className="preloader-bar-fill" />
        </div>
        <p className="preloader-cap">A preparar o seu ecossistema</p>
      </div>
    </div>
  );
}
