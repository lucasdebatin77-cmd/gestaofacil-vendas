"use client";

import { useEffect, useRef, useState } from "react";

type Event = { id: number; agent: string; action: string; meta: string };

const POOL: Omit<Event, "id">[] = [
  { agent: "Radar", action: "detectou alta em “sérum vitamina C”", meta: "+18%" },
  { agent: "Precificação", action: "reajustou margem em 3 SKUs", meta: "ótimo" },
  { agent: "Afiliados", action: "aprovou 2 novos afiliados", meta: "match 94%" },
  { agent: "Campanhas", action: "reduziu CPC em “beleza”", meta: "-12%" },
  { agent: "Atendimento", action: "respondeu 14 dúvidas de clientes", meta: "95% CSAT" },
  { agent: "Insights", action: "gerou relatório semanal executivo", meta: "pronto" },
  { agent: "Logística", action: "antecipou reposição de estoque", meta: "7 dias" },
  { agent: "Radar", action: "sinalizou oportunidade em “home office”", meta: "nova" },
];

const INITIAL: Event[] = [
  { id: 1, ...POOL[0] },
  { id: 2, ...POOL[2] },
  { id: 3, ...POOL[3] },
  { id: 4, ...POOL[5] },
];

export default function LiveFeed() {
  const [items, setItems] = useState<Event[]>(INITIAL);
  const seq = useRef(5);

  useEffect(() => {
    const id = setInterval(() => {
      const pick = POOL[Math.floor(Math.random() * POOL.length)];
      seq.current += 1;
      setItems((prev) => [{ id: seq.current, ...pick }, ...prev].slice(0, 5));
    }, 2100);
    return () => clearInterval(id);
  }, []);

  return (
    <div className="flex flex-col gap-2.5" aria-live="polite">
      {items.map((it, i) => (
        <div
          key={it.id}
          className="flex items-start gap-3 rounded-xl border border-[var(--color-line)] bg-white/[0.025] px-3 py-2.5"
          style={{ animation: "feed-in 0.5s cubic-bezier(0.16,1,0.3,1)" }}
        >
          <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-[var(--color-cyan)] shadow-[0_0_8px_2px_rgba(88,214,230,0.6)]" />
          <div className="min-w-0">
            <p className="truncate text-sm text-[var(--color-cream)]">
              <span className="font-medium text-[var(--color-gold)]">{it.agent}</span>{" "}
              {it.action}
            </p>
            <p className="mt-0.5 text-xs text-[var(--color-mist-soft)]">
              {it.meta} · {i === 0 ? "agora" : `${i * 2}s atrás`}
            </p>
          </div>
        </div>
      ))}
    </div>
  );
}
