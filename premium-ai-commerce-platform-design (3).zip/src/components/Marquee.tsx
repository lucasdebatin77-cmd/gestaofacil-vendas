const PARTNERS = [
  "Shopify",
  "Mercado Livre",
  "Amazon",
  "Hotmart",
  "Kiwify",
  "Eduzz",
  "WooCommerce",
  "Nuvemshop",
  "Vtex",
  "Kirvano",
];

export default function Marquee() {
  const row = [...PARTNERS, ...PARTNERS];
  return (
    <section className="relative border-y border-[var(--color-line)] bg-[var(--color-ink-soft)]/40 py-7">
      <div className="container-lux mb-5 text-center">
        <p className="text-[0.7rem] tracking-[0.32em] uppercase text-[var(--color-mist-soft)]">
          Plataformas e canais conectados ao ecossistema
        </p>
      </div>
      <div className="relative overflow-hidden [mask-image:linear-gradient(90deg,transparent,#000_12%,#000_88%,transparent)]">
        <div className="flex w-max animate-marquee items-center gap-14 pr-14">
          {row.map((name, i) => (
            <span
              key={`${name}-${i}`}
              className="flex shrink-0 items-center gap-3 font-display text-2xl font-medium text-[var(--color-mist)]/70"
            >
              <span className="h-1.5 w-1.5 rounded-full bg-[var(--color-gold)]/60" />
              {name}
            </span>
          ))}
        </div>
      </div>
    </section>
  );
}
