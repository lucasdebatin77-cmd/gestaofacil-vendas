import Reveal from "./Reveal";

const STEPS = [
  {
    n: "01",
    title: "Conecte",
    body: "Integre sua loja, marketplaces e plataformas parceiras em minutos — via API, webhooks ou conectores nativos. Sem migração disruptiva.",
  },
  {
    n: "02",
    title: "Unifique",
    body: "Reúna produtos, pedidos, comissões e dados de afiliados em um único painel. Sua operação comercial deixa de viver em planilhas isoladas.",
  },
  {
    n: "03",
    title: "Decida",
    body: "Receba do Radar e dos agentes de IA recomendações acionáveis em tempo real — e automatize o que antes exigia horas de trabalho manual.",
  },
];

export default function HowItWorks() {
  return (
    <section className="relative py-24 sm:py-32">
      <div className="container-lux">
        <Reveal className="mx-auto max-w-2xl text-center">
          <span className="eyebrow">Como funciona</span>
          <h2 className="mt-6 text-[clamp(2rem,4.5vw,3.4rem)] font-light">
            Do primeiro login à decisão, <span className="text-gradient">em três passos.</span>
          </h2>
          <p className="mt-5 text-[var(--color-mist)]">
            Uma implementação guiada e sem atrito. Você conecta as fontes que já usa
            e a inteligência da GestãoFácil passa a operar por você.
          </p>
        </Reveal>

        <div className="relative mt-16 grid gap-6 md:grid-cols-3">
          {/* connecting line */}
          <div className="pointer-events-none absolute left-0 right-0 top-9 hidden border-t border-dashed border-[var(--color-line)] md:block" />

          {STEPS.map((s, i) => (
            <Reveal key={s.n} delay={i * 120}>
              <div className="relative h-full">
                <div className="relative z-10 flex h-16 w-16 items-center justify-center rounded-2xl border border-[var(--color-line)] bg-[var(--color-ink-raised)] font-display text-2xl font-medium text-gradient">
                  {s.n}
                </div>
                <h3 className="mt-6 text-2xl font-medium">{s.title}</h3>
                <p className="mt-3 text-sm leading-relaxed text-[var(--color-mist)]">{s.body}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
