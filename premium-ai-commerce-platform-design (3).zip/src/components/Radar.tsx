"use client";

import { useEffect, useRef, useState } from "react";

const CATEGORIES = ["Beleza", "Eletrônicos", "Casa", "Fitness"] as const;
type Category = (typeof CATEGORIES)[number];

const SERIES: Record<Category, number[]> = {
  Beleza: [22, 30, 27, 41, 38, 52, 49, 63, 71, 66, 82, 94],
  Eletrônicos: [48, 44, 52, 47, 58, 54, 61, 57, 66, 72, 69, 78],
  Casa: [18, 24, 22, 33, 30, 42, 46, 44, 55, 58, 64, 71],
  Fitness: [35, 42, 39, 51, 60, 57, 68, 74, 70, 81, 88, 96],
};

const W = 600;
const H = 220;

function buildPath(points: number[], max: number) {
  const step = W / (points.length - 1);
  return points
    .map((v, i) => {
      const x = i * step;
      const y = H - (v / max) * (H - 20) - 10;
      return `${i === 0 ? "M" : "L"}${x.toFixed(1)},${y.toFixed(1)}`;
    })
    .join(" ");
}

export default function Radar() {
  const [cat, setCat] = useState<Category>("Beleza");
  const [hover, setHover] = useState<number | null>(null);
  const wrapRef = useRef<HTMLDivElement>(null);
  const [played, setPlayed] = useState(false);

  const points = SERIES[cat];
  const max = Math.max(...CATEGORIES.flatMap((c) => SERIES[c]));
  const line = buildPath(points, max);
  const area = `${line} L${W},${H} L0,${H} Z`;
  const last = points[points.length - 1];
  const delta = (((last - points[0]) / points[0]) * 100).toFixed(0);

  // replay animation on category change
  useEffect(() => {
    setPlayed(false);
    const t = requestAnimationFrame(() => requestAnimationFrame(() => setPlayed(true)));
    return () => cancelAnimationFrame(t);
  }, [cat]);

  // first reveal when scrolled into view
  useEffect(() => {
    const el = wrapRef.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      ([e]) => {
        if (e.isIntersecting) {
          setPlayed(true);
          obs.disconnect();
        }
      },
      { threshold: 0.3 },
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, []);

  const step = W / (points.length - 1);

  const kpis = [
    { label: "Produtos em alta", value: "1.284", delta: "+12,4%" },
    { label: "Sentimento", value: "92%", delta: "+3,1%" },
    { label: "Conversão prevista", value: "7,8%", delta: "+0,9 p.p." },
    { label: "Oportunidades", value: "37", delta: "novas" },
  ];

  return (
    <section id="radar" className="relative py-24 sm:py-32">
      <div className="container-lux">
        <div className="grid items-center gap-14 lg:grid-cols-2">
          {/* copy */}
          <div>
            <span className="eyebrow">Radar de Produtos</span>
            <h2 className="mt-6 text-[clamp(2rem,4.5vw,3.4rem)] font-light">
              Veja o que o mercado{" "}
              <span className="text-gradient-ai">vai querer</span> antes dele.
            </h2>
            <p className="mt-5 max-w-xl text-[var(--color-mist)]">
              O Radar cruza sinais de demanda, sentimento e conversão em tempo real.
              Você recebe alertas de oportunidade e recomendações acionáveis — sem
              montar uma única planilha.
            </p>

            <ul className="mt-8 space-y-3">
              {[
                "Detecção de tendências por categoria e região",
                "Alertas inteligentes de oportunidade de venda",
                "Comparativo de desempenho contra plataformas parceiras",
              ].map((t) => (
                <li key={t} className="flex items-start gap-3 text-sm text-[var(--color-cream)]/90">
                  <span className="mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded-full bg-[rgba(34,211,238,0.12)] text-[var(--color-cyan)]">
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                      <path d="M20 6L9 17l-5-5" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                  </span>
                  {t}
                </li>
              ))}
            </ul>
          </div>

          {/* interactive dashboard */}
          <div ref={wrapRef} className="glass-strong rounded-3xl p-5 shadow-[0_40px_120px_-40px_rgba(0,0,0,0.9)]">
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[var(--color-line)] pb-4">
              <div className="flex items-center gap-2.5">
                <span className="relative flex h-2.5 w-2.5">
                  <span className="absolute inline-flex h-full w-full rounded-full bg-[var(--color-cyan)] opacity-75 [animation:pulse-ring_2s_ease-out_infinite]" />
                  <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-[var(--color-cyan)]" />
                </span>
                <span className="text-xs font-medium tracking-wide text-[var(--color-mist)]">RADAR · AO VIVO</span>
              </div>
              <div role="tablist" aria-label="Categorias do Radar" className="flex flex-wrap gap-1.5">
                {CATEGORIES.map((c) => (
                  <button
                    key={c}
                    role="tab"
                    aria-selected={cat === c}
                    onClick={() => setCat(c)}
                    data-cursor
                    className={`rounded-full border px-3 py-1 text-[0.7rem] transition-all duration-300 ${
                      cat === c
                        ? "border-[rgba(125,211,252,0.55)] bg-[rgba(34,211,238,0.14)] text-[var(--color-cyan)]"
                        : "border-[var(--color-line)] text-[var(--color-mist)] hover:border-[rgba(125,211,252,0.35)] hover:text-[var(--color-cream)]"
                    }`}
                  >
                    {c}
                  </button>
                ))}
              </div>
            </div>

            {/* chart */}
            <div
              className="relative mt-4"
              onMouseLeave={() => setHover(null)}
            >
              <svg viewBox={`0 0 ${W} ${H}`} className="h-44 w-full" preserveAspectRatio="none">
                <defs>
                  <linearGradient id="lineGrad" x1="0" y1="0" x2="1" y2="0">
                    <stop offset="0%" stopColor="#22d3ee" />
                    <stop offset="50%" stopColor="#a855f7" />
                    <stop offset="100%" stopColor="#fb923c" />
                  </linearGradient>
                  <linearGradient id="areaGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="rgba(168,85,247,0.35)" />
                    <stop offset="100%" stopColor="rgba(168,85,247,0)" />
                  </linearGradient>
                </defs>

                {[0.25, 0.5, 0.75].map((g) => (
                  <line key={g} x1="0" x2={W} y1={H * g} y2={H * g} stroke="rgba(255,255,255,0.05)" strokeWidth="1" />
                ))}

                <path d={area} fill="url(#areaGrad)" opacity={played ? 1 : 0} style={{ transition: "opacity 1s ease 0.35s" }} />
                <path
                  key={cat}
                  d={line}
                  fill="none"
                  stroke="url(#lineGrad)"
                  strokeWidth="2.5"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  pathLength={1}
                  style={{
                    strokeDasharray: 1,
                    strokeDashoffset: played ? 0 : 1,
                    transition: "stroke-dashoffset 1.8s cubic-bezier(0.16,1,0.3,1)",
                  }}
                />

                {/* hover hit areas */}
                {points.map((v, i) => {
                  const x = i * step;
                  const y = H - (v / max) * (H - 20) - 10;
                  const on = hover === i;
                  return (
                    <g key={`${cat}-${i}`}>
                      <rect
                        x={x - step / 2}
                        y={0}
                        width={step}
                        height={H}
                        fill="transparent"
                        onMouseEnter={() => setHover(i)}
                      />
                      {on && <line x1={x} x2={x} y1={y} y2={H} stroke="rgba(255,255,255,0.18)" strokeWidth="1" />}
                      <circle
                        cx={x}
                        cy={y}
                        r={on ? 5 : 2.5}
                        fill={on ? "#fb923c" : "#7dd3fc"}
                        opacity={played ? 1 : 0}
                        style={{ transition: "opacity 0.5s ease 1.2s, r 0.2s ease", pointerEvents: "none" }}
                      />
                    </g>
                  );
                })}
              </svg>

              {/* tooltip */}
              {hover !== null && (
                <div
                  className="pointer-events-none absolute z-10 -translate-x-1/2 -translate-y-[135%] rounded-lg border border-[rgba(125,211,252,0.4)] bg-[rgba(7,10,22,0.95)] px-2.5 py-1.5 text-center shadow-lg"
                  style={{
                    left: `${((hover * step) / W) * 100}%`,
                    top: `${((H - (points[hover] / max) * (H - 20) - 10) / H) * 100}%`,
                  }}
                >
                  <p className="text-[0.7rem] font-semibold text-[var(--color-cream)]">
                    {points[hover]} pts
                  </p>
                  <p className="text-[0.6rem] text-[var(--color-mist-soft)]">
                    Semana {hover + 1} · {cat}
                  </p>
                </div>
              )}
            </div>

            {/* trend summary */}
            <div className="mt-2 flex items-center justify-between text-[0.7rem] text-[var(--color-mist-soft)]">
              <span>Sem. 1</span>
              <span className="text-[var(--color-cyan)]">
                {cat}: {points[0]} → {last} pts · <strong className="text-[var(--color-cream)]">+{delta}%</strong>
              </span>
              <span>Sem. 12</span>
            </div>

            {/* kpis */}
            <div className="mt-4 grid grid-cols-2 gap-3">
              {kpis.map((k) => (
                <div key={k.label} className="rounded-2xl border border-[var(--color-line)] bg-white/[0.02] p-3.5">
                  <p className="text-[0.7rem] text-[var(--color-mist-soft)]">{k.label}</p>
                  <div className="mt-1 flex items-end justify-between">
                    <span className="font-display text-2xl font-medium text-[var(--color-cream)]">{k.value}</span>
                    <span className="text-[0.7rem] font-medium text-[var(--color-cyan)]">{k.delta}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
