type Props = {
  size?: "sm" | "md" | "lg";
  withTagline?: boolean;
  className?: string;
};

const SIZES = {
  sm: { mark: 30, word: "text-[1.15rem]", tag: "text-[0.5rem]", gap: "gap-2" },
  md: { mark: 40, word: "text-[1.5rem]", tag: "text-[0.58rem]", gap: "gap-2.5" },
  lg: { mark: 62, word: "text-[clamp(2rem,5vw,3rem)]", tag: "text-[0.75rem]", gap: "gap-4" },
};

export function PrismMark({ size = 30, className = "" }: { size?: number; className?: string }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 64 64"
      fill="none"
      aria-hidden="true"
      className={`shrink-0 ${className}`}
    >
      <defs>
        <linearGradient id="prismGrad" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#22d3ee" />
          <stop offset="0.32" stopColor="#6366f1" />
          <stop offset="0.6" stopColor="#a855f7" />
          <stop offset="0.82" stopColor="#ec4899" />
          <stop offset="1" stopColor="#fb923c" />
        </linearGradient>
        <linearGradient id="prismFacet" x1="0" y1="1" x2="1" y2="0">
          <stop offset="0" stopColor="#fb923c" />
          <stop offset="0.5" stopColor="#ec4899" />
          <stop offset="1" stopColor="#22d3ee" />
        </linearGradient>
      </defs>
      {/* outer prism body */}
      <path
        d="M32 9.5 L54.5 50.5 L9.5 50.5 Z"
        fill="none"
        stroke="url(#prismGrad)"
        strokeWidth="7.5"
        strokeLinejoin="round"
      />
      {/* inner facet triangle */}
      <path
        d="M32 26.5 L43.5 46.5 L20.5 46.5 Z"
        fill="none"
        stroke="url(#prismFacet)"
        strokeWidth="4"
        strokeLinejoin="round"
        opacity="0.95"
      />
      {/* light facet edge */}
      <path
        d="M32 9.5 L32 26.5 M9.5 50.5 L20.5 46.5 M54.5 50.5 L43.5 46.5"
        stroke="url(#prismGrad)"
        strokeWidth="2"
        opacity="0.6"
      />
    </svg>
  );
}

export default function Logo({ size = "md", withTagline = false, className = "" }: Props) {
  const s = SIZES[size];
  return (
    <span className={`flex items-center ${s.gap} ${className}`}>
      <PrismMark size={s.mark} />
      <span className="flex flex-col leading-none">
        <span className={`font-mark font-extrabold tracking-[-0.03em] ${s.word}`}>
          <span className="text-chrome">Gestão</span>
          <span className="text-spectrum">Fácil</span>
        </span>
        {withTagline && (
          <span className="mt-1.5 flex items-center gap-2">
            <span className="spectrum-rule w-6" />
            <span
              className={`font-mark font-semibold tracking-[0.4em] text-[var(--color-mist)] ${s.tag}`}
            >
              VENDAS
            </span>
            <span className="spectrum-rule w-6" />
          </span>
        )}
      </span>
    </span>
  );
}
