"use client";

import { useEffect, useState } from "react";

const SECTIONS = [
  { id: "top", label: "Início" },
  { id: "ecossistema", label: "Ecossistema" },
  { id: "radar", label: "Radar" },
  { id: "inteligencia", label: "Inteligência" },
  { id: "acesso", label: "Acesso" },
];

export default function SectionRail() {
  const [active, setActive] = useState("top");

  useEffect(() => {
    const els = SECTIONS.map((s) => document.getElementById(s.id)).filter(
      (el): el is HTMLElement => Boolean(el),
    );
    if (!els.length) return;

    const obs = new IntersectionObserver(
      (entries) => {
        const visible = entries
          .filter((e) => e.isIntersecting)
          .sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
        if (visible) setActive(visible.target.id);
      },
      { rootMargin: "-40% 0px -50% 0px", threshold: [0, 0.25, 0.5] },
    );
    els.forEach((el) => obs.observe(el));
    return () => obs.disconnect();
  }, []);

  return (
    <nav
      aria-label="Índice de seções"
      className="fixed left-5 top-1/2 z-40 hidden -translate-y-1/2 flex-col gap-1 xl:flex"
    >
      {SECTIONS.map((s) => {
        const on = active === s.id;
        return (
          <a
            key={s.id}
            href={`#${s.id}`}
            data-cursor
            className="group flex items-center gap-3 py-1.5"
            aria-current={on ? "true" : undefined}
          >
            <span
              className={`h-px transition-all duration-500 ${
                on
                  ? "w-8 bg-[linear-gradient(90deg,#22d3ee,#a855f7)]"
                  : "w-4 bg-[var(--color-line)] group-hover:w-6 group-hover:bg-[var(--color-mist-soft)]"
              }`}
            />
            <span
              className={`text-[0.66rem] font-medium uppercase tracking-[0.22em] transition-all duration-500 ${
                on
                  ? "translate-x-0 text-[var(--color-cream)] opacity-100"
                  : "-translate-x-1 text-[var(--color-mist-soft)] opacity-0 group-hover:translate-x-0 group-hover:opacity-100"
              }`}
            >
              {s.label}
            </span>
          </a>
        );
      })}
    </nav>
  );
}
