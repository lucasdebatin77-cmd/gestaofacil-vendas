"use client";

import { useEffect, useRef, useState } from "react";
import AuroraField from "./AuroraField";
import MagneticButton from "./MagneticButton";
import { PrismMark } from "./Logo";

const WORDS: { t: string; cls?: string }[] = [
  { t: "Sua" },
  { t: "operação" },
  { t: "comercial," },
  { t: "unificada", cls: "text-gradient" },
  { t: "e" },
  { t: "inteligente.", cls: "text-gradient-ai" },
];

const ORBIT = [
  {
    angle: 0,
    label: "Marketplace",
    sub: "Vitrine curada",
    icon: <path d="M3 4h2l2.4 12.3a2 2 0 002 1.7h7.7a2 2 0 002-1.6L21 8H6M9 21a1 1 0 100-2 1 1 0 000 2zm9 0a1 1 0 100-2 1 1 0 000 2z" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />,
  },
  {
    angle: 120,
    label: "SaaS Comercial",
    sub: "Centro de comando",
    icon: <path d="M4 5h7v7H4zM13 5h7v7h-7zM4 14h7v5H4zM13 14h7v5h-7z" stroke="currentColor" strokeWidth="1.6" strokeLinejoin="round" />,
  },
  {
    angle: 240,
    label: "Inteligência",
    sub: "Radar + IA",
    icon: <path d="M12 3l2.2 5.5L20 11l-5.8 2.5L12 19l-2.2-5.5L4 11l5.8-2.5z" stroke="currentColor" strokeWidth="1.6" strokeLinejoin="round" />,
  },
];

const STATUS = [
  "Analisando tendências",
  "Otimizando campanhas",
  "Aprovando afiliados",
  "Ajustando preços",
  "Gerando insights",
];

export default function Hero({ leadCount }: { leadCount: number }) {
  const heroRef = useRef<HTMLElement>(null);
  const glowRef = useRef<HTMLDivElement>(null);
  const orbitRef = useRef<HTMLDivElement>(null);
  const [ready, setReady] = useState(false);
  const [status, setStatus] = useState(STATUS[0]);

  useEffect(() => {
    const onReady = () => setReady(true);
    window.addEventListener("gf:ready", onReady);
    const fallback = setTimeout(() => setReady(true), 2800);
    return () => {
      window.removeEventListener("gf:ready", onReady);
      clearTimeout(fallback);
    };
  }, []);

  useEffect(() => {
    const hero = heroRef.current;
    const glow = glowRef.current;
    if (!hero || !glow) return;
    const onMove = (e: PointerEvent) => {
      const rect = hero.getBoundingClientRect();
      const x = ((e.clientX - rect.left) / rect.width) * 100;
      const y = ((e.clientY - rect.top) / rect.height) * 100;
      glow.style.background = `radial-gradient(440px circle at ${x}% ${y}%, rgba(34,211,238,0.13), rgba(168,85,247,0.10) 38%, transparent 62%)`;
    };
    hero.addEventListener("pointermove", onMove);
    return () => hero.removeEventListener("pointermove", onMove);
  }, []);

  useEffect(() => {
    let i = 0;
    const id = setInterval(() => {
      i = (i + 1) % STATUS.length;
      setStatus(STATUS[i]);
    }, 2600);
    return () => clearInterval(id);
  }, []);

  useEffect(() => {
    const orbit = orbitRef.current;
    if (!orbit) return;
    let raf = 0;
    const onScroll = () => {
      if (raf) return;
      raf = requestAnimationFrame(() => {
        const y = window.scrollY;
        orbit.style.transform = `translateY(${Math.min(y * 0.07, 72)}px)`;
        raf = 0;
      });
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => {
      window.removeEventListener("scroll", onScroll);
      if (raf) cancelAnimationFrame(raf);
    };
  }, []);

  return (
    <section
      id="top"
      ref={heroRef}
      className="relative isolate flex min-h-[100svh] items-center overflow-hidden pt-28 pb-16"
    >
      <AuroraField />
      <div ref={glowRef} className="pointer-events-none absolute inset-0 z-[1]" aria-hidden="true" />

      <div className="container-lux relative z-10">
        <div className="grid items-center gap-12 lg:grid-cols-[1.05fr_0.95fr]">
          {/* copy */}
          <div className={ready ? "ready" : ""}>
            <div className="inline-flex items-center gap-2 rounded-full border border-[var(--color-line)] bg-white/[0.03] px-4 py-1.5 text-xs font-medium tracking-[0.18em] text-[var(--color-cyan)]">
              <span className="h-1.5 w-1.5 rounded-full bg-[var(--color-cyan)] shadow-[0_0_10px_2px_rgba(34,211,238,0.7)]" />
              COMÉRCIO DIGITAL · INTELIGÊNCIA ARTIFICIAL
            </div>

            <h1 className="mt-7 text-[clamp(2.6rem,6.4vw,5.4rem)] font-light leading-[0.98]">
              {WORDS.map((w, i) => (
                <span key={i} className="word-mask">
                  <span
                    className={`word-inner ${w.cls ?? ""}`}
                    style={{ transitionDelay: `${0.15 + i * 0.08}s` }}
                  >
                    {w.t}
                    {i < WORDS.length - 1 ? " " : ""}
                  </span>
                </span>
              ))}
            </h1>

            <p className="mt-7 max-w-xl text-pretty text-base leading-relaxed text-[var(--color-mist)] sm:text-lg">
              Marketplace, SaaS comercial e inteligência de negócios reunidos em uma
              única plataforma. Conecte suas lojas e canais, automatize a operação e
              decida com base em dados — com agentes de IA treinados para o seu negócio.
            </p>

            <div className="mt-10 flex flex-col items-start gap-3 sm:flex-row sm:items-center">
              <MagneticButton href="#acesso" className="btn-gold w-full sm:w-auto">
                Solicitar acesso antecipado
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                  <path d="M5 12h14M13 6l6 6-6 6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              </MagneticButton>
              <MagneticButton href="#radar" className="btn-ghost w-full sm:w-auto">
                Conheça o Radar
              </MagneticButton>
            </div>

            <div className="mt-12 flex items-center gap-3 text-sm text-[var(--color-mist-soft)]">
              <div className="flex -space-x-2.5">
                {["#22d3ee", "#6366f1", "#a855f7", "#fb923c"].map((c) => (
                  <span
                    key={c}
                    className="h-7 w-7 rounded-full border border-[var(--color-ink)]"
                    style={{ background: `radial-gradient(circle at 30% 30%, ${c}, #1a1d27)` }}
                  />
                ))}
              </div>
              <span>
                <strong className="font-semibold text-[var(--color-cream)]">
                  {leadCount.toLocaleString("pt-BR")}
                </strong>{" "}
                marcas e afiliados na lista de acesso
              </span>
            </div>

            <div className="mt-9 flex items-center gap-2.5 text-xs text-[var(--color-mist)]">
              <span className="relative flex h-2 w-2">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-[var(--color-cyan)] opacity-70" />
                <span className="relative inline-flex h-2 w-2 rounded-full bg-[var(--color-cyan)]" />
              </span>
              Operação ao vivo ·{" "}
              <span className="font-medium text-[var(--color-champagne)]">{status}</span>
            </div>
          </div>

          {/* orbiting composition */}
          <div ref={orbitRef} className="relative mx-auto hidden aspect-square w-full max-w-[520px] will-change-transform lg:block">
            {/* concentric rings */}
            <div className="absolute left-1/2 top-1/2 h-[78%] w-[78%] -translate-x-1/2 -translate-y-1/2 rounded-full border border-[var(--color-line)]" />
            <div className="absolute left-1/2 top-1/2 h-[100%] w-[100%] -translate-x-1/2 -translate-y-1/2 rounded-full border border-[var(--color-line-soft)]" />

            {/* core */}
            <div className="absolute left-1/2 top-1/2 z-10 -translate-x-1/2 -translate-y-1/2">
              <div className="relative grid h-40 w-40 place-items-center rounded-full border border-[rgba(125,211,252,0.32)] bg-[radial-gradient(circle_at_30%_30%,#111a33,#060914)] [animation:core-pulse_5s_ease-in-out_infinite]">
                <div className="radar-sweep" />
                <span className="relative z-10 animate-float">
                  <PrismMark size={72} />
                </span>
                <span className="absolute bottom-3 z-10 text-[0.6rem] tracking-[0.28em] text-[var(--color-mist-soft)]">
                  NÚCLEO IA
                </span>
              </div>
            </div>

            {/* orbiting cards */}
            <div className="orbit-ring">
              {ORBIT.map((o) => (
                <div
                  key={o.label}
                  className="orbit-item"
                  style={{ transform: `rotate(${o.angle}deg) translateY(-210px)` }}
                >
                  <div className="orbit-card w-[150px]">
                    <div className="glass-strong rounded-2xl p-4 text-center shadow-[0_24px_60px_-24px_rgba(0,0,0,0.9)]">
                      <span className="mx-auto grid h-10 w-10 place-items-center rounded-xl border border-[var(--color-line)] bg-[rgba(34,211,238,0.09)] text-[var(--color-cyan)]">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                          {o.icon}
                        </svg>
                      </span>
                      <p className="mt-3 text-sm font-medium text-[var(--color-cream)]">{o.label}</p>
                      <p className="text-[0.7rem] text-[var(--color-mist-soft)]">{o.sub}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* floating data pills */}
            <div className="absolute left-2 top-6 chip animate-float">+312% tendência</div>
            <div className="absolute right-0 bottom-10 chip animate-float" style={{ animationDelay: "-3s" }}>
              ao vivo
            </div>
          </div>
        </div>
      </div>

      <a
        href="#ecossistema"
        className="absolute bottom-7 left-1/2 z-10 hidden -translate-x-1/2 flex-col items-center gap-2 text-[var(--color-mist-soft)] transition-colors hover:text-[var(--color-champagne)] sm:flex"
        aria-label="Rolar para o ecossistema"
      >
        <span className="text-[0.65rem] tracking-[0.3em] uppercase">Role</span>
        <span className="grid h-9 w-5 place-items-start rounded-full border border-[var(--color-line)] p-1">
          <span className="h-1.5 w-1.5 rounded-full bg-[var(--color-champagne)] [animation:scroll-hint_1.8s_ease-in-out_infinite]" />
        </span>
      </a>
    </section>
  );
}
