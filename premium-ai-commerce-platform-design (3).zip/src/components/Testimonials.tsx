import Reveal from "./Reveal";

const QUOTES = [
  {
    text: "Migramos marketplace, afiliados e relatórios para a GestãoFácil. Pela primeira vez, enxergo o negócio inteiro numa só tela — e a IA já nos antecipou duas tendências antes da concorrência.",
    name: "Helena Marques",
    role: "Fundadora · Lúmina Cosméticos",
  },
  {
    text: "Como afiliado, o Radar mudou meu jogo. Eu sei exatamente quais produtos estão em alta e recebo os links prontos para promover. Minha conversão dobrou em dois meses.",
    name: "Rafael Tavares",
    role: "Afiliado premium · 42k seguidores",
  },
  {
    text: "O SaaS comercial eliminou nossas planilhas. Campanhas, comissões e pedidos rodam sozinhos, e os agentes cuidam do que antes ocupava minha equipe comercial inteira.",
    name: "Beatriz Nunes",
    role: "Diretora Comercial · Varejo Nova Era",
  },
];

export default function Testimonials() {
  return (
    <section className="relative py-24 sm:py-32">
      <div className="container-lux">
        <Reveal className="mx-auto max-w-2xl text-center">
          <span className="eyebrow">Quem vive o ecossistema</span>
          <h2 className="mt-6 text-[clamp(2rem,4.5vw,3.4rem)] font-light">
            Resultados que falam <span className="text-gradient">alto.</span>
          </h2>
        </Reveal>

        <div className="mt-14 grid gap-6 md:grid-cols-3">
          {QUOTES.map((q, i) => (
            <Reveal key={q.name} delay={i * 120}>
              <figure className="card-lux flex h-full flex-col p-8">
                <div className="font-display text-6xl leading-none text-[var(--color-gold)]/40">&ldquo;</div>
                <blockquote className="mt-2 flex-1 text-[var(--color-cream)]/90 leading-relaxed">
                  {q.text}
                </blockquote>
                <figcaption className="mt-6 flex items-center gap-3 border-t border-[var(--color-line)] pt-5">
                  <span className="grid h-10 w-10 place-items-center rounded-full bg-[linear-gradient(135deg,#22d3ee,#6366f1_40%,#a855f7_70%,#fb923c)] font-display text-lg font-semibold text-[#04060f]">
                    {q.name.charAt(0)}
                  </span>
                  <span>
                    <span className="block text-sm font-medium text-[var(--color-cream)]">{q.name}</span>
                    <span className="block text-xs text-[var(--color-mist-soft)]">{q.role}</span>
                  </span>
                </figcaption>
              </figure>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
