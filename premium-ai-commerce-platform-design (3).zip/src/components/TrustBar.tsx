import Reveal from "./Reveal";

const ITEMS = [
  { label: "Conformidade LGPD", icon: "M12 3l7 3v5c0 4.4-3 8.2-7 9-4-0.8-7-4.6-7-9V6l7-3z" },
  { label: "Criptografia AES-256", icon: "M6 10V8a6 6 0 1112 0v2M5 10h14v9a2 2 0 01-2 2H7a2 2 0 01-2-2v-9z" },
  { label: "SLA de 99,9%", icon: "M13 3L4 14h7l-1 7 9-11h-7l1-7z" },
  { label: "APIs e webhooks", icon: "M8 7l-5 5 5 5M16 7l5 5-5 5M14 4l-4 16" },
  { label: "SSO e RBAC", icon: "M12 12a4 4 0 100-8 4 4 0 000 8zM5 21a7 7 0 0114 0" },
];

export default function TrustBar() {
  return (
    <section className="relative border-y border-[var(--color-line)] bg-[var(--color-ink-soft)]/40 py-6">
      <div className="container-lux">
        <Reveal className="flex flex-col items-center justify-between gap-5 lg:flex-row">
          <span className="text-[0.7rem] font-semibold tracking-[0.28em] uppercase text-[var(--color-mist-soft)]">
            Padrão enterprise
          </span>
          <div className="flex flex-wrap items-center justify-center gap-x-8 gap-y-3">
            {ITEMS.map((it) => (
              <span key={it.label} className="flex items-center gap-2 text-sm text-[var(--color-mist)]">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" aria-hidden="true" className="text-[var(--color-gold)]">
                  <path d={it.icon} stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
                {it.label}
              </span>
            ))}
          </div>
        </Reveal>
      </div>
    </section>
  );
}
