import Reveal from "./Reveal";

const BADGES = [
  { label: "LGPD", sub: "Lei Geral de Proteção de Dados" },
  { label: "ISO 27001", sub: "Gestão de segurança da informação" },
  { label: "SSL / TLS", sub: "Tráfego criptografado de ponta a ponta" },
  { label: "SSO / SAML", sub: "Acesso corporativo e federado" },
  { label: "RBAC", sub: "Permissões por função e escopo" },
  { label: "Backups", sub: "Retenção e recuperação contínua" },
];

const POINTS = [
  "Dados acessados somente com consentimento explícito do titular",
  "Criptografia em repouso (AES-256) e em trânsito (TLS 1.3)",
  "Trilha de auditoria imutável para cada ação sensível",
  "Isolamento por conta e segregação de ambientes",
];

export default function Security() {
  return (
    <section className="relative overflow-hidden border-y border-[var(--color-line)] bg-[var(--color-ink-soft)]/50 py-24 sm:py-32">
      <div className="pointer-events-none absolute -left-32 top-1/2 hidden h-[28rem] w-[28rem] -translate-y-1/2 rounded-full bg-[radial-gradient(circle,rgba(88,214,230,0.12),transparent_60%)] blur-[90px] lg:block" />

      <div className="container-lux relative">
        <div className="grid gap-14 lg:grid-cols-[0.9fr_1.1fr] lg:items-center">
          <Reveal>
            <span className="eyebrow">Segurança & conformidade</span>
            <h2 className="mt-6 text-[clamp(2rem,4.5vw,3.4rem)] font-light">
              Construído para ambientes <span className="text-gradient">exigentes.</span>
            </h2>
            <p className="mt-5 max-w-md text-[var(--color-mist)]">
              A GestãoFácil trata dados como ativo crítico. Privacidade e governança
              não são promessas de marketing — são premissas de arquitetura.
            </p>
            <ul className="mt-8 space-y-3.5">
              {POINTS.map((p) => (
                <li key={p} className="flex items-start gap-3 text-sm text-[var(--color-cream)]/90">
                  <span className="mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded-full bg-[rgba(88,214,230,0.12)] text-[var(--color-cyan)]">
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                      <path d="M20 6L9 17l-5-5" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                  </span>
                  {p}
                </li>
              ))}
            </ul>
          </Reveal>

          <Reveal delay={120}>
            <div className="grid grid-cols-2 gap-4 sm:grid-cols-3">
              {BADGES.map((b) => (
                <div
                  key={b.label}
                  className="glass rounded-2xl p-5 text-center transition-colors duration-500 hover:border-[rgba(125,211,252,0.35)]"
                >
                  <span className="grid h-11 w-11 mx-auto place-items-center rounded-xl border border-[var(--color-line)] bg-[linear-gradient(140deg,rgba(34,211,238,0.14),rgba(168,85,247,0.14))] text-[var(--color-cyan)]">
                    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                      <path d="M12 3l7 3v5c0 4.4-3 8.2-7 9-4-0.8-7-4.6-7-9V6l7-3z" stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round" />
                    </svg>
                  </span>
                  <p className="mt-3 font-display text-lg font-medium text-[var(--color-cream)]">{b.label}</p>
                  <p className="mt-1 text-[0.7rem] leading-snug text-[var(--color-mist-soft)]">{b.sub}</p>
                </div>
              ))}
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
