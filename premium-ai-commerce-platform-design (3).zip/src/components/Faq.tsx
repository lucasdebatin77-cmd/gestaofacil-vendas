"use client";

import { useState } from "react";

const ITEMS = [
  {
    q: "A GestãoFácil substitui minha loja atual?",
    a: "Não. Ela se conecta às suas plataformas parceiras. O consumidor pode comprar direto na plataforma ou ser direcionado à sua loja, com rastreio completo de conversão.",
  },
  {
    q: "Como a inteligência comercial acessa meus dados?",
    a: "Somente com sua autorização explícita. Você controla quais fontes e dados cada agente de IA pode utilizar — nada é ativado sem o seu consentimento.",
  },
  {
    q: "Serve para afiliados ou só para quem vende?",
    a: "Para os dois. Vendedores administram produtos, campanhas e comissões; afiliados descobrem oportunidades no Radar e recebem links prontos para promover.",
  },
  {
    q: "Quando o acesso antecipado abre?",
    a: "As primeiras marcas e afiliados entram em ondas controladas. Ao entrar na lista, você garante prioridade e condições exclusivas de lançamento.",
  },
  {
    q: "É seguro?",
    a: "Sim. Operamos sob consentimento e boas práticas de privacidade. Seus dados autorizados são usados apenas para gerar inteligência a seu favor.",
  },
];

export default function Faq() {
  const [open, setOpen] = useState<number | null>(0);

  return (
    <section className="relative py-24 sm:py-32">
      <div className="container-lux">
        <div className="grid gap-12 lg:grid-cols-[0.8fr_1.2fr]">
          <div className="lg:sticky lg:top-28 lg:self-start">
            <span className="eyebrow">Dúvidas frequentes</span>
            <h2 className="mt-6 text-[clamp(1.9rem,4vw,3rem)] font-light">
              Tudo o que você <span className="text-gradient">precisa saber.</span>
            </h2>
            <p className="mt-5 max-w-sm text-[var(--color-mist)]">
              Ainda assim, fale com a gente — nossa equipe responde pessoalmente a
              cada solicitação de acesso.
            </p>
          </div>

          <div className="divide-y divide-[var(--color-line)] border-t border-[var(--color-line)]">
            {ITEMS.map((item, i) => {
              const isOpen = open === i;
              return (
                <div key={item.q}>
                  <button
                    type="button"
                    onClick={() => setOpen(isOpen ? null : i)}
                    aria-expanded={isOpen}
                    className="flex w-full items-center justify-between gap-6 py-6 text-left"
                  >
                    <span className="font-display text-xl font-medium text-[var(--color-cream)]">
                      {item.q}
                    </span>
                    <span
                      className={`grid h-9 w-9 shrink-0 place-items-center rounded-full border border-[var(--color-line)] text-[var(--color-gold)] transition-transform duration-500 ${
                        isOpen ? "rotate-45" : ""
                      }`}
                    >
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                        <path d="M12 5v14M5 12h14" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
                      </svg>
                    </span>
                  </button>
                  <div
                    className={`grid overflow-hidden transition-all duration-500 ease-[cubic-bezier(0.16,1,0.3,1)] ${
                      isOpen ? "grid-rows-[1fr] opacity-100" : "grid-rows-[0fr] opacity-0"
                    }`}
                  >
                    <div className="min-h-0">
                      <p className="max-w-xl pb-6 text-sm leading-relaxed text-[var(--color-mist)]">
                        {item.a}
                      </p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
