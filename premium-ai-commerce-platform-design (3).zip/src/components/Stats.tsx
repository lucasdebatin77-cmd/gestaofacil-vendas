"use client";

import { useEffect, useRef, useState } from "react";

const STATS = [
  { value: 12000, suffix: "+", label: "produtos mapeados no Radar" },
  { value: 3, suffix: " em 1", label: "negócios no ecossistema" },
  { value: 98, suffix: "%", label: "das tarefas comercias automatizadas" },
  { value: 24, suffix: "/7", label: "agentes de IA em operação" },
];

function useCountUp(target: number, active: boolean) {
  const [val, setVal] = useState(0);
  useEffect(() => {
    if (!active) return;
    let raf = 0;
    const start = performance.now();
    const duration = 1600;
    const tick = (now: number) => {
      const p = Math.min(1, (now - start) / duration);
      const eased = 1 - Math.pow(1 - p, 3);
      setVal(Math.round(eased * target));
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [target, active]);
  return val;
}

function Stat({ value, suffix, label }: (typeof STATS)[number]) {
  const ref = useRef<HTMLDivElement>(null);
  const [active, setActive] = useState(false);
  const count = useCountUp(value, active);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      ([e]) => {
        if (e.isIntersecting) {
          setActive(true);
          obs.disconnect();
        }
      },
      { threshold: 0.4 },
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, []);

  return (
    <div ref={ref} className="relative text-center">
      <div className="font-display text-[clamp(2.6rem,5vw,4rem)] font-light leading-none">
        <span className="text-gradient">{count.toLocaleString("pt-BR")}</span>
        <span className="text-gradient-ai">{suffix}</span>
      </div>
      <p className="mt-3 text-sm text-[var(--color-mist)]">{label}</p>
    </div>
  );
}

export default function Stats() {
  return (
    <section className="relative border-y border-[var(--color-line)] bg-[var(--color-ink-soft)]/50">
      <div className="container-lux grid gap-10 py-16 sm:grid-cols-2 lg:grid-cols-4">
        {STATS.map((s) => (
          <Stat key={s.label} {...s} />
        ))}
      </div>
    </section>
  );
}
