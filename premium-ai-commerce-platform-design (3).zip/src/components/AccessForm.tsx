"use client";

import { useEffect, useState } from "react";

const BUSINESS = [
  { value: "marketplace", label: "Tenho um marketplace" },
  { value: "vendor", label: "Vendo produtos" },
  { value: "affiliate", label: "Sou afiliado(a)" },
  { value: "brand", label: "Tenho uma marca" },
  { value: "agency", label: "Agência / Consultoria" },
  { value: "other", label: "Outro" },
];

type Status = "idle" | "loading" | "success" | "error";

export default function AccessForm({ initialCount }: { initialCount: number }) {
  const [count, setCount] = useState(initialCount);
  const [status, setStatus] = useState<Status>("idle");
  const [error, setError] = useState("");
  const [form, setForm] = useState({
    name: "",
    email: "",
    businessType: "vendor",
    message: "",
  });

  useEffect(() => {
    fetch("/api/leads")
      .then((r) => r.json())
      .then((d) => typeof d.count === "number" && setCount(d.count))
      .catch(() => {});
  }, []);

  const update = (key: keyof typeof form, value: string) =>
    setForm((f) => ({ ...f, [key]: value }));

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setStatus("loading");
    setError("");
    try {
      const res = await fetch("/api/leads", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        setStatus("error");
        setError(data.error ?? "Não foi possível enviar. Tente novamente.");
        return;
      }
      setStatus("success");
      setCount((c) => c + 1);
    } catch {
      setStatus("error");
      setError("Erro de conexão. Tente novamente.");
    }
  }

  return (
    <section id="acesso" className="relative overflow-hidden py-24 sm:py-32">
      {/* ribbon band imagery */}
      <img
        src="images/ribbon-band.jpg"
        alt=""
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 h-full w-full object-cover opacity-30"
        style={{
          maskImage: "radial-gradient(90% 80% at 50% 100%, #000 10%, transparent 75%)",
          WebkitMaskImage: "radial-gradient(90% 80% at 50% 100%, #000 10%, transparent 75%)",
        }}
      />
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(60%_50%_at_50%_0%,rgba(34,211,238,0.10),transparent_70%)]" />

      <div className="container-lux relative grid gap-12 lg:grid-cols-[1fr_1.05fr] lg:items-center">
        {/* pitch */}
        <div>
          <span className="eyebrow">Acesso antecipado</span>
          <h2 className="mt-6 text-[clamp(2rem,4.5vw,3.4rem)] font-light">
            Entre para o <span className="text-gradient">círculo restrito.</span>
          </h2>
          <p className="mt-5 max-w-md text-[var(--color-mist)]">
            Abriremos o ecossistema em ondas. Quem entra na lista garante prioridade,
            onboarding dedicado e condições exclusivas de lançamento.
          </p>

          <ul className="mt-8 space-y-3">
            {[
              "Prioridade na liberação do seu ecossistema",
              "Acesso antecipado ao Radar de Produtos",
              "Condições exclusivas de lançamento",
            ].map((t) => (
              <li key={t} className="flex items-center gap-3 text-sm text-[var(--color-cream)]/90">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true" className="text-[var(--color-gold)]">
                  <path d="M20 6L9 17l-5-5" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
                {t}
              </li>
            ))}
          </ul>

          <p className="mt-10 text-sm text-[var(--color-mist-soft)]">
            <strong className="font-semibold text-[var(--color-champagne)]">
              {count.toLocaleString("pt-BR")}
            </strong>{" "}
            marcas e afiliados já na lista
          </p>
        </div>

        {/* form */}
        <div className="glass-strong rounded-3xl p-7 sm:p-9">
          {status === "success" ? (
            <div className="flex flex-col items-center justify-center py-10 text-center">
              <span className="grid h-16 w-16 place-items-center rounded-full bg-[linear-gradient(140deg,rgba(34,211,238,0.22),rgba(168,85,247,0.22))] text-[var(--color-cyan)]">
                <svg width="30" height="30" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                  <path d="M20 6L9 17l-5-5" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              </span>
              <h3 className="mt-6 text-2xl font-medium">Você está na lista.</h3>
              <p className="mt-3 max-w-xs text-sm text-[var(--color-mist)]">
                Recebemos seu interesse. Falaremos pessoalmente assim que sua
                vaga no ecossistema for liberada.
              </p>
              <button
                type="button"
                onClick={() => {
                  setStatus("idle");
                  setForm({ name: "", email: "", businessType: "vendor", message: "" });
                }}
                className="btn-ghost mt-7"
              >
                Indicar outro e-mail
              </button>
            </div>
          ) : (
            <form onSubmit={onSubmit} className="space-y-5" noValidate>
              <div>
                <label htmlFor="name" className="mb-2 block text-xs font-medium tracking-wide text-[var(--color-mist)]">
                  Nome completo
                </label>
                <input
                  id="name"
                  required
                  value={form.name}
                  onChange={(e) => update("name", e.target.value)}
                  placeholder="Como podemos te chamar?"
                  className="w-full rounded-xl border border-[var(--color-line)] bg-white/[0.03] px-4 py-3 text-sm text-[var(--color-cream)] outline-none transition-colors placeholder:text-[var(--color-mist-soft)] focus:border-[var(--color-gold)]"
                />
              </div>

              <div>
                <label htmlFor="email" className="mb-2 block text-xs font-medium tracking-wide text-[var(--color-mist)]">
                  E-mail profissional
                </label>
                <input
                  id="email"
                  type="email"
                  required
                  value={form.email}
                  onChange={(e) => update("email", e.target.value)}
                  placeholder="voce@empresa.com"
                  className="w-full rounded-xl border border-[var(--color-line)] bg-white/[0.03] px-4 py-3 text-sm text-[var(--color-cream)] outline-none transition-colors placeholder:text-[var(--color-mist-soft)] focus:border-[var(--color-gold)]"
                />
              </div>

              <div>
                <label htmlFor="businessType" className="mb-2 block text-xs font-medium tracking-wide text-[var(--color-mist)]">
                  Seu perfil
                </label>
                <select
                  id="businessType"
                  value={form.businessType}
                  onChange={(e) => update("businessType", e.target.value)}
                  className="w-full rounded-xl border border-[var(--color-line)] bg-[var(--color-ink-raised)] px-4 py-3 text-sm text-[var(--color-cream)] outline-none transition-colors focus:border-[var(--color-gold)]"
                >
                  {BUSINESS.map((b) => (
                    <option key={b.value} value={b.value} className="bg-[var(--color-ink-raised)]">
                      {b.label}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label htmlFor="message" className="mb-2 block text-xs font-medium tracking-wide text-[var(--color-mist)]">
                  O que você mais quer resolver? <span className="text-[var(--color-mist-soft)]">(opcional)</span>
                </label>
                <textarea
                  id="message"
                  rows={3}
                  value={form.message}
                  onChange={(e) => update("message", e.target.value)}
                  placeholder="Conte brevemente seu objetivo no ecossistema."
                  className="w-full resize-none rounded-xl border border-[var(--color-line)] bg-white/[0.03] px-4 py-3 text-sm text-[var(--color-cream)] outline-none transition-colors placeholder:text-[var(--color-mist-soft)] focus:border-[var(--color-gold)]"
                />
              </div>

              {status === "error" && (
                <p className="rounded-lg border border-red-500/30 bg-red-500/10 px-4 py-3 text-sm text-red-300">
                  {error}
                </p>
              )}

              <button
                type="submit"
                disabled={status === "loading"}
                className="btn-gold w-full disabled:opacity-70"
              >
                {status === "loading" ? "Enviando..." : "Quero entrar na lista"}
              </button>
              <p className="text-center text-xs text-[var(--color-mist-soft)]">
                Tratamos seus dados conforme a LGPD. Sem spam — e você pode solicitar
                a exclusão a qualquer momento.
              </p>
            </form>
          )}
        </div>
      </div>
    </section>
  );
}
