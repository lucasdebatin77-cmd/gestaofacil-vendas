"use client";

import { useEffect, useState } from "react";
import Logo from "./Logo";

const LINKS = [
  { label: "Ecossistema", href: "#ecossistema" },
  { label: "Radar", href: "#radar" },
  { label: "Inteligência", href: "#inteligencia" },
  { label: "Acesso", href: "#acesso" },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={`fixed inset-x-0 top-0 z-50 transition-all duration-500 ${
        scrolled
          ? "border-b border-[var(--color-line)] bg-[rgba(7,8,12,0.72)] backdrop-blur-xl"
          : "border-b border-transparent"
      }`}
    >
      <nav className="container-lux flex h-[72px] items-center justify-between">
        <a href="#top" className="group flex items-center" aria-label="GestãoFácil Vendas — início">
          <Logo size="md" />
        </a>

        <div className="hidden items-center gap-9 md:flex">
          {LINKS.map((l) => (
            <a
              key={l.href}
              href={l.href}
              className="relative text-sm text-[var(--color-mist)] transition-colors hover:text-[var(--color-cream)] after:absolute after:-bottom-1.5 after:left-0 after:h-px after:w-0 after:bg-[var(--color-gold)] after:transition-all after:duration-300 hover:after:w-full"
            >
              {l.label}
            </a>
          ))}
        </div>

        <div className="flex items-center gap-3">
          <a href="#acesso" className="btn-gold hidden px-5 py-2.5 text-sm sm:inline-flex">
            Entrar na lista
          </a>
          <button
            type="button"
            aria-label="Abrir menu"
            onClick={() => setOpen((v) => !v)}
            className="grid h-10 w-10 place-items-center rounded-lg border border-[var(--color-line)] bg-white/[0.03] md:hidden"
          >
            <span className="flex flex-col gap-[5px]">
              <span className={`h-px w-5 bg-[var(--color-cream)] transition-transform ${open ? "translate-y-[6px] rotate-45" : ""}`} />
              <span className={`h-px w-5 bg-[var(--color-cream)] transition-opacity ${open ? "opacity-0" : ""}`} />
              <span className={`h-px w-5 bg-[var(--color-cream)] transition-transform ${open ? "-translate-y-[6px] -rotate-45" : ""}`} />
            </span>
          </button>
        </div>
      </nav>

      <div
        className={`overflow-hidden border-t border-[var(--color-line)] bg-[rgba(7,8,12,0.92)] backdrop-blur-xl transition-[max-height,opacity] duration-500 md:hidden ${
          open ? "max-h-80 opacity-100" : "max-h-0 opacity-0"
        }`}
      >
        <div className="container-lux flex flex-col gap-1 py-4">
          {LINKS.map((l) => (
            <a
              key={l.href}
              href={l.href}
              onClick={() => setOpen(false)}
              className="rounded-lg px-3 py-3 text-[var(--color-mist)] transition-colors hover:bg-white/[0.04] hover:text-[var(--color-cream)]"
            >
              {l.label}
            </a>
          ))}
          <a href="#acesso" onClick={() => setOpen(false)} className="btn-gold mt-2 w-full">
            Entrar na lista
          </a>
        </div>
      </div>
    </header>
  );
}
