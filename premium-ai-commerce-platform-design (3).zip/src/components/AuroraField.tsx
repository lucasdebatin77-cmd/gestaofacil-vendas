export default function AuroraField({ className = "" }: { className?: string }) {
  return (
    <div className={`pointer-events-none absolute inset-0 overflow-hidden ${className}`} aria-hidden="true">
      {/* stage image */}
      <img
        src="images/hero-stage.jpg"
        alt=""
        className="absolute inset-0 h-full w-full object-cover opacity-45"
        style={{
          maskImage: "radial-gradient(130% 100% at 50% 30%, #000 35%, transparent 85%)",
          WebkitMaskImage: "radial-gradient(130% 100% at 50% 30%, #000 35%, transparent 85%)",
        }}
      />
      <div className="absolute inset-0 bg-[linear-gradient(180deg,rgba(4,6,15,0.55)_0%,rgba(4,6,15,0.2)_45%,rgba(4,6,15,0.92)_100%)]" />

      {/* drifting spectrum orbs */}
      <div className="animate-aurora absolute -left-[10%] top-[8%] h-[42rem] w-[42rem] rounded-full bg-[radial-gradient(circle,rgba(34,211,238,0.30),transparent_60%)] blur-[90px]" />
      <div
        className="animate-aurora absolute -right-[12%] top-[2%] h-[38rem] w-[38rem] rounded-full bg-[radial-gradient(circle,rgba(168,85,247,0.30),transparent_60%)] blur-[90px]"
        style={{ animationDelay: "-7s" }}
      />
      <div
        className="animate-aurora absolute left-[20%] top-[40%] h-[34rem] w-[34rem] rounded-full bg-[radial-gradient(circle,rgba(236,72,153,0.18),transparent_60%)] blur-[80px]"
        style={{ animationDelay: "-14s" }}
      />
      <div
        className="animate-aurora absolute right-[8%] bottom-[-8%] h-[30rem] w-[30rem] rounded-full bg-[radial-gradient(circle,rgba(251,146,60,0.16),transparent_60%)] blur-[80px]"
        style={{ animationDelay: "-20s" }}
      />

      {/* fine grid */}
      <div
        className="absolute inset-0 opacity-[0.16]"
        style={{
          backgroundImage:
            "linear-gradient(rgba(255,255,255,0.05) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.05) 1px, transparent 1px)",
          backgroundSize: "64px 64px",
          maskImage: "radial-gradient(120% 80% at 50% 0%, #000 30%, transparent 80%)",
          WebkitMaskImage: "radial-gradient(120% 80% at 50% 0%, #000 30%, transparent 80%)",
        }}
      />
    </div>
  );
}
