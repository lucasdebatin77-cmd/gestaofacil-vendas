import Logo from "./Logo";

const COLUMNS = [
  {
    title: "Produto",
    links: ["Marketplace", "SaaS Comercial", "Radar de Produtos", "Agentes de IA"],
  },
  {
    title: "Ecossistema",
    links: ["Para Marcas", "Para Vendedores", "Para Afiliados", "Parceiros"],
  },
  {
    title: "Empresa",
    links: ["Sobre", "Inteligência", "Carreiras", "Contato"],
  },
];

export default function Footer() {
  return (
    <footer className="relative border-t border-[var(--color-line)] bg-[var(--color-ink-soft)]/60">
      <div className="container-lux py-16">
        <div className="grid gap-12 lg:grid-cols-[1.4fr_1fr_1fr_1fr]">
          <div>
            <a href="#top" aria-label="GestãoFácil Vendas — início">
              <Logo size="md" withTagline />
            </a>
            <p className="mt-5 max-w-xs text-sm leading-relaxed text-[var(--color-mist)]">
              O ecossistema comercial com inteligência artificial: marketplace,
              SaaS e inteligência de negócios em uma só plataforma.
            </p>
            <div className="mt-6 flex gap-3">
              {["Instagram", "LinkedIn", "YouTube"].map((s) => (
                <a
                  key={s}
                  href="#top"
                  className="chip transition-colors hover:border-[var(--color-gold)] hover:text-[var(--color-cream)]"
                >
                  {s}
                </a>
              ))}
            </div>
          </div>

          {COLUMNS.map((col) => (
            <div key={col.title}>
              <h4 className="font-display text-lg font-medium text-[var(--color-cream)]">
                {col.title}
              </h4>
              <ul className="mt-4 space-y-3">
                {col.links.map((l) => (
                  <li key={l}>
                    <a
                      href="#top"
                      className="text-sm text-[var(--color-mist)] transition-colors hover:text-[var(--color-champagne)]"
                    >
                      {l}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-14 flex flex-col items-center justify-between gap-4 border-t border-[var(--color-line)] pt-8 text-center text-xs text-[var(--color-mist-soft)] sm:flex-row sm:text-left">
          <p>© {new Date().getFullYear()} GestãoFácil. Todos os direitos reservados.</p>
          <p className="order-first sm:order-none">Em conformidade com a LGPD · Dados tratados com consentimento.</p>
          <div className="flex gap-6">
            <a href="#top" className="transition-colors hover:text-[var(--color-cream)]">Privacidade</a>
            <a href="#top" className="transition-colors hover:text-[var(--color-cream)]">Termos</a>
            <a href="#top" className="transition-colors hover:text-[var(--color-cream)]">Segurança</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
