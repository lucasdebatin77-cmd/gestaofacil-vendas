import { db } from "@/db";
import { leads } from "@/db/schema";
import { sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

const BUSINESS_TYPES = new Set([
  "marketplace",
  "vendor",
  "affiliate",
  "brand",
  "agency",
  "other",
]);

export async function POST(req: Request) {
  try {
    const body = await req.json().catch(() => null);
    if (!body) {
      return Response.json({ error: "Requisição inválida." }, { status: 400 });
    }

    const name = String(body.name ?? "").trim();
    const email = String(body.email ?? "").trim().toLowerCase();
    const businessType = body.businessType ? String(body.businessType) : null;
    const message = body.message ? String(body.message).slice(0, 1000) : null;

    if (name.length < 2) {
      return Response.json({ error: "Informe seu nome completo." }, { status: 400 });
    }
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) {
      return Response.json({ error: "Informe um e-mail válido." }, { status: 400 });
    }
    if (businessType && !BUSINESS_TYPES.has(businessType)) {
      return Response.json({ error: "Tipo de negócio inválido." }, { status: 400 });
    }

    await db.insert(leads).values({
      name: name.slice(0, 160),
      email: email.slice(0, 254),
      businessType,
      message,
    });

    return Response.json({ ok: true });
  } catch {
    return Response.json(
      { error: "Não foi possível registrar seu acesso. Tente novamente." },
      { status: 500 },
    );
  }
}

export async function GET() {
  try {
    const [row] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(leads);
    return Response.json({ count: row?.count ?? 0 });
  } catch {
    return Response.json({ count: 0 });
  }
}
