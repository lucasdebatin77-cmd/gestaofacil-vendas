import type { Metadata } from "next";
import type { ReactNode } from "react";
import { Cormorant_Garamond, Inter, Poppins } from "next/font/google";
import "./globals.css";

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-inter",
  display: "swap",
});

const cormorant = Cormorant_Garamond({
  subsets: ["latin"],
  weight: ["300", "400", "500", "600", "700"],
  variable: "--font-cormorant",
  display: "swap",
});

const poppins = Poppins({
  subsets: ["latin"],
  weight: ["600", "700", "800"],
  variable: "--font-mark",
  display: "swap",
});

export const metadata: Metadata = {
  title: "GestãoFácil Vendas — O ecossistema comercial com inteligência artificial",
  description:
    "Marketplace público, SaaS comercial e inteligência de negócios reunidos em um único ecossistema. Descubra, venda e decida com o Radar de Produtos e agentes de IA da GestãoFácil.",
  keywords: [
    "GestãoFácil",
    "GestãoFácil Vendas",
    "marketplace",
    "SaaS comercial",
    "inteligência artificial",
    "Radar de Produtos",
    "comércio digital",
    "afiliados",
  ],
  authors: [{ name: "GestãoFácil Vendas" }],
  openGraph: {
    title: "GestãoFácil Vendas — Comércio digital com inteligência",
    description:
      "Três negócios, um único ecossistema: marketplace, SaaS e inteligência comercial com IA.",
    type: "website",
  },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="pt-BR" className={`${inter.variable} ${cormorant.variable} ${poppins.variable}`}>
      <body>
        <div className="vignette" aria-hidden="true" />
        <div className="grain" aria-hidden="true" />
        {children}
      </body>
    </html>
  );
}
