import { db } from "@/db";
import { leads } from "@/db/schema";
import { sql } from "drizzle-orm";

import Navbar from "@/components/Navbar";
import Hero from "@/components/Hero";
import Marquee from "@/components/Marquee";
import TrustBar from "@/components/TrustBar";
import Ecosystem from "@/components/Ecosystem";
import HowItWorks from "@/components/HowItWorks";
import Stats from "@/components/Stats";
import Radar from "@/components/Radar";
import Intelligence from "@/components/Intelligence";
import Security from "@/components/Security";
import BrandBand from "@/components/BrandBand";
import Testimonials from "@/components/Testimonials";
import Faq from "@/components/Faq";
import AccessForm from "@/components/AccessForm";
import Footer from "@/components/Footer";
import Preloader from "@/components/Preloader";
import CustomCursor from "@/components/CustomCursor";
import ScrollProgress from "@/components/ScrollProgress";
import SectionRail from "@/components/SectionRail";

export const dynamic = "force-dynamic";

async function getLeadCount(): Promise<number> {
  try {
    const [row] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(leads);
    return row?.count ?? 0;
  } catch {
    return 0;
  }
}

export default async function HomePage() {
  const leadCount = await getLeadCount();

  return (
    <>
      <Preloader />
      <CustomCursor />
      <ScrollProgress />
      <SectionRail />
      <Navbar />
      <main>
        <Hero leadCount={leadCount} />
        <Marquee />
        <TrustBar />
        <Ecosystem />
        <HowItWorks />
        <Stats />
        <Radar />
        <Intelligence />
        <Security />
        <BrandBand />
        <Testimonials />
        <Faq />
        <AccessForm initialCount={leadCount} />
      </main>
      <Footer />
    </>
  );
}
